<template>
  <div class="page">
    <div class="page__hd">
      <div class="page__title">Flex</div>
      <div class="page__desc">Flex布局</div>
    </div>
    <div class="page__bd page__bd_spacing">
      <div class="weui-flex">
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
      </div>
      <div class="weui-flex">
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
      </div>
      <div class="weui-flex">
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
      </div>
      <div class="weui-flex">
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
      </div>
      <div class="weui-flex">
        <div>
          <div class="placeholder">weui</div>
        </div>
        <div class="weui-flex__item">
          <div class="placeholder">weui</div>
        </div>
        <div>
          <div class="placeholder">weui</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.placeholder {
  margin: 5px;
  padding: 0 10px;
  text-align: center;
  background-color: #ebebeb;
  height: 2.3em;
  line-height: 2.3em;
  color: #cfcfcf;
}
</style>
