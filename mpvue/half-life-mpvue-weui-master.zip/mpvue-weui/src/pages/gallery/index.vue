<template>
  <div class="page">
    <div class="page__hd">
        <div class="page__title">Gallery</div>
        <div class="page__desc">画廊，建议采用小程序原生的wx.chooseImage和wx.previewImage来实现。详情请看小程序文档。</div>
    </div>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
