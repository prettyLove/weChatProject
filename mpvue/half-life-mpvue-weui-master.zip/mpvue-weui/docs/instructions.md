# 相关说明

#### 1. 版权问题

本项目[mpvue-weui](https://github.com/KuangPF/mpvue-weui)主要使用了 [weui-wxss](https://github.com/Tencent/weui-wxss) 中的相关文件，主要目的在于交流学习，如果冒犯了相关的开源协议，实属抱歉。

#### 2. 内容问题

这篇文档是自己在重写了 `WeUI` 以后记录的，如果有说的不对的地方还希望各位大佬指出，一起学习。
