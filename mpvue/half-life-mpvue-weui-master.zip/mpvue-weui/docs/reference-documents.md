# 参考文档

本文档主要参考  [weui-wiki](https://github.com/Tencent/weui/wiki)   和   [小程序开发文档](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)
