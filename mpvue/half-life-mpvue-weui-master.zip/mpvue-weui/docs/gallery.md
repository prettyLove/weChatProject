# Gallery
Gallery用于实现上传图片的展示或幻灯片播放

这里推荐使用小程序原生的`wx.chooseImage`和`wx.previewImage`来实现,例子可以参照 [uploader](uploader.md)中图片预览的效果。

**效果**

![gallery](_img/uploader/uploader02.gif)
