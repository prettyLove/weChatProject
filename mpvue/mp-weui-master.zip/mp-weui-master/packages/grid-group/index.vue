<template>
  <div class="weui-grids">
    <slot />
  </div>
</template>

<script>
export default {
  name: 'MpGridGroup',
};
</script>
