<template>
  <div class="page">
    <div class="page__hd">
      <div class="page__title">Tabbar</div>
      <div class="page__desc">底部导航，建议采用小程序原生的tabbar，通过设置app.json来实现。详情请看小程序文档。</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

