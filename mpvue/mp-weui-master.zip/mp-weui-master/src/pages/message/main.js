import Vue from 'vue';
import App from './index';

new Vue(App).$mount();

